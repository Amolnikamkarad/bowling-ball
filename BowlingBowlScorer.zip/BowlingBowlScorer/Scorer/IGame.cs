﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scorer
{
    interface IGame
    {
        void Roll(int[] pins);
        void Roll(int pins);
        bool isSpare(int frameIndex);
        bool isStrike(int frameIndex);
    }
}
